package com.radioandactive.minicommerce.database

import androidx.room.ColumnInfo
import androidx.room.PrimaryKey

data class ProductFromDatabase(
    @PrimaryKey(autoGenerate = true) val uid: Int?,
    @ColumnInfo val title: String,
    @ColumnInfo val price: Double
)