package com.radioandactive.minicommerce

import android.os.Bundle
import android.support.v4.view.GravityCompat
import android.support.v7.app.AppCompatActivity;
import android.util.Log.d
import android.view.MenuItem
import androidx.room.Room
import com.radioandactive.minicommerce.database.AppDatabase
import com.radioandactive.minicommerce.database.ProductFromDatabase
import kotlinx.android.synthetic.main.activity_main.*

import kotlinx.android.synthetic.main.main.*
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(toolbar)

        doAsync {
            val db = Room.databaseBuilder(
                applicationContext,
                AppDatabase::class.java, "database-name"
            ).build()

            db.productDao().insertAll(ProductFromDatabase(null, "Socks", 1.99))
            val prds = db.productDao().getAll()

            uiThread {
                d("kelvin", "product size? ${prds.size}")
            }
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.frame_layout, MainFragment())
            .commit()

        navigation_view.setNavigationItemSelectedListener {
            when(it.itemId) {
                R.id.action_home -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame_layout, MainFragment())
                        .commit()
                }
                R.id.action_jeans -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.frame_layout, JeansFragment())
                        .commit()
                    d("jeans", "jeans was pressed")
                }
                R.id.action_shorts -> d("jeans", "shorts was pressed")
            }
            it.isChecked = true
            drawer_layout.closeDrawers()
            true
        }

        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            setHomeAsUpIndicator(R.drawable.ic_menu_white_24dp)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        drawer_layout.openDrawer(GravityCompat.START)
        return super.onOptionsItemSelected(item)
    }
}
